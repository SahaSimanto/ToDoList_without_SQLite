package com.example.assignment_2_todolist_without_sqlite;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<String> taskList;
    private ArrayAdapter<String> taskAdapter;
    private ListView listViewTasks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        listViewTasks = findViewById(R.id.item_list);
        taskList = new ArrayList<>();
        taskAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, taskList);
        listViewTasks.setAdapter(taskAdapter);


        setupListViewLongClickListener();


        Button buttonAddTask = findViewById(R.id.addItemButton);
        buttonAddTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addNewTask();
            }
        });
    }


    private void addNewTask() {
        EditText inputTask = findViewById(R.id.addNewItem);
        String taskText = inputTask.getText().toString().trim();
        if (!taskText.isEmpty()) {
            taskList.add(taskText);
            taskAdapter.notifyDataSetChanged();
            inputTask.setText("");
        }
    }


    private void setupListViewLongClickListener() {
        listViewTasks.setOnItemLongClickListener((adapterView, view, position, id) -> {
            taskList.remove(position);
            taskAdapter.notifyDataSetChanged();
            return true;
        });
    }
}
